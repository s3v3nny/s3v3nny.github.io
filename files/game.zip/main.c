#include <ctype.h>
#include <stdlib.h>
#include <unistd.h>

#include <ncurses.h>

#include "structs/participant.h"
#include "structs/pos.h"
#include "structs/rectangle.h"

#include "util/error.h"
#include "util/filepath.h"
#include "util/help.h"

struct Pos get_pos_for_position_on_rectangle(struct Rectangle rectangle, int position) {
	struct Pos result;

	if (position < rectangle.width) {
		result.x = position;
		result.y = 0;
	} else if (position < rectangle.width + rectangle.height - 1) {
		result.x = rectangle.width - 1;
		result.y = position - rectangle.width;
	} else if (position < (2 * rectangle.width) + rectangle.height - 2) {
		result.x = rectangle.width - 1 - (position - (rectangle.width + rectangle.height - 1));
		result.y = rectangle.height - 1;
	} else {
		result.x = 0;
		result.y = rectangle.height - 1 - (position - ((2 * rectangle.width) + rectangle.height - 2));
	}

	return result;
}

void draw_ui(struct Rectangle rectangle, struct Participant* participants, int participants_num) {
	clear();
	
	// Draw Rectangle
	int starty = 0;
	int endy = rectangle.height - 1;

	int startx = 0;
	int endx = rectangle.width - 1;

    for (int x = startx; x <= endx; x++) {
        mvaddch(starty, x, '*');
        mvaddch(endy, x, '*');
    }

    for (int y = starty; y <= endy; y++) {
        mvaddch(y, startx, '*');
        mvaddch(y, endx, '*');
    }

	// Put participants
	for (int i = 0; i < participants_num; i++) {
		struct Pos position = get_pos_for_position_on_rectangle(rectangle, participants[i].place);
		mvaddch(position.y, position.x, participants[i].name);
	}

	// Draw Text
	int text_print_y_start = rectangle.height + 3;
	//mvprintw(text_print_y_start, 0, "Game leader: %c");
	if (participants_num == 1) {
		mvprintw(text_print_y_start + 1, 0, "Participant %c won the game!", participants[0].name);
	} else {
		mvprintw(text_print_y_start + 1, 0, "Press S to count the next one out");
	}
	mvprintw(text_print_y_start + 2, 0, "Press C to start over");
	mvprintw(text_print_y_start + 3, 0, "Press ESC to quit");
	move(text_print_y_start + 4, 0);

	refresh();
}

// Too lazy to put into local vars.
int prevX = 0;
int prevY = 0;

char play_animation_and_find_participant_to_count_out(struct Rectangle rectangle, struct Participant* participants, int participants_num, int K) {
	// Find where to put cursor first
	move(prevY, prevX);

	// Start playing animation
	int counter = 0;
	int x = prevX;
	int y = prevY;
	char c;
	while (counter != K) {
		if (y == 0 && x != rectangle.width - 1) {
			++x;
		} else if (x == rectangle.width - 1 && y != rectangle.height - 1) {
			++y;
		} else if (y == rectangle.height - 1 && x != 0) {
			--x;
		} else {
			--y;
		}

		c = (char)mvinch(y, x);
		if (c != '*') ++counter;

		// Draw status text
		int text_print_y_start = rectangle.height + 1;
		mvprintw(text_print_y_start, 0, "Counting: %d", counter);
		if (counter == K) {
			mvprintw(text_print_y_start + 1, 0, "%c counted out!", c);
		}
		move(y, x);

		refresh();
		usleep(300000);
	}

	// Return the counted out participant's name
	prevX = x;
	prevY = y;

	return c;
}

int main(int argc, char** argv) {
    if (argc != 3) {
	    char* executable_name = get_executable_name(argv[0]);
	    display_usage(executable_name);
	    return 1;
    }

    int participants_num = atoi(argv[1]);
    int K = atoi(argv[2]);
    
	const int MAX_PARTICIPANTS = 'Z' - 'A' + 1; // Every participant has unique char as a name.

    if (participants_num > MAX_PARTICIPANTS) {
	    display_error_message_max_participants(participants_num, MAX_PARTICIPANTS);
	    return 1;
    }

	initscr();

    int alive_participants_num;

start:
    alive_participants_num = participants_num;

    struct Rectangle rectangle = create_rectangle(participants_num);
    struct Participant* participants = create_participants(participants_num);
    place_participants(participants, participants_num, get_perimeter(rectangle));

    while (alive_participants_num > 1) {
    	draw_ui(rectangle, participants, alive_participants_num);
    	char counted_out = play_animation_and_find_participant_to_count_out(rectangle, participants, alive_participants_num, K);

    	char input = tolower(getch());
    	if (input == 's') {
			struct Participant* new_participants_ptr = (struct Participant*)malloc(sizeof(struct Participant) * (alive_participants_num - 1));
			for (int i = 0, j = 0; i < alive_participants_num; i++) {
				if (participants[i].name == counted_out) {
					continue;
				}

				new_participants_ptr[j].name = participants[i].name;
				new_participants_ptr[j].place = participants[i].place;
				j++;
			}
			free(participants);
			participants = new_participants_ptr;
    		alive_participants_num -= 1;
    	} else if (input == 'c') {
    		free(participants);
			goto start;
    	} else if (input == 27) {
    		free(participants);
			endwin();
    		exit(0);
    	}
    }

    while (1) {
		draw_ui(rectangle, participants, alive_participants_num);

    	char input = tolower(getch());
    	if (input == 'c') {
			free(participants);
    		goto start;
    	}
    	else if (input == 27) {
			free(participants);
			endwin();
    		exit(0);
    	}
    }
}
