#pragma once

#include <stdio.h>

void display_error_message_max_participants(int participants, int max_participants) {
	printf("Number of participants %d should be less than %d", participants, max_participants);
}
