#pragma once

struct Rectangle {
	int width;
	int height;
};

static int get_perimeter(struct Rectangle rectangle) {
    return 2 * rectangle.width + 2 * rectangle.height - 4;
}

struct Rectangle create_rectangle(int min_perimeter) {
	struct Rectangle result;

	result.width = 4;
	result.height = 3;

	int perimeter = get_perimeter(result);

	while (perimeter < min_perimeter) {
		result.width += 4;
		result.height += 3;
		perimeter = get_perimeter(result);
	}

	return result;
}
