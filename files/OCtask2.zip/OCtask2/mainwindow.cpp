#include <QInputDialog>
#include <QString>
#include <QLabel>
#include <QMessageBox>
#include <QString>

#include "mainwindow.h"
#include "./ui_mainwindow.h"
#include "structs/pos.h"

#include <vector>


std::vector<int> participants = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
int K;
int counter = 0;
int position = 1;
int participants_alive = 10;


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{

    ui->setupUi(this);
    ui->p1->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p2->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p3->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p4->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p5->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p6->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p7->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p8->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p9->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p10->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");

    ui->cursor->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/cursor.png)");


    ui->cursor->move(90, 58);
    ui->p1->move(90, 90);
    ui->p2->move(124, 90);
    ui->p3->move(158, 90);
    ui->p4->move(192, 90);

    ui->p5->move(192, 124);

    ui->p6->move(192, 158);
    ui->p7->move(158, 158);
    ui->p8->move(124, 158);
    ui->p9->move(90, 158);

    ui->p10->move(90, 124);

    getK();
}


MainWindow::~MainWindow()
{
    delete ui;
}

Pos MainWindow::find_cursor_position(int pos) {
    struct Pos cursor_pos;
    switch (pos){
    case 1:
        cursor_pos.x = 90;
        cursor_pos.y = 58;
        return cursor_pos;
    case 2:
        cursor_pos.x = 124;
        cursor_pos.y = 58;
        return cursor_pos;
        break;
    case 3:
        cursor_pos.x = 158;
        cursor_pos.y = 58;
        return cursor_pos;
        break;
    case 4:
        cursor_pos.x = 192;
        cursor_pos.y = 58;
        return cursor_pos;
        break;
    case 5:
        cursor_pos.x = 226;
        cursor_pos.y = 124;
        return cursor_pos;
        break;
    case 6:
        cursor_pos.x = 192;
        cursor_pos.y = 192;
        return cursor_pos;
        break;
    case 7:
        cursor_pos.x = 158;
        cursor_pos.y = 192;
        return cursor_pos;
        break;
    case 8:
        cursor_pos.x = 124;
        cursor_pos.y = 192;
        return cursor_pos;
        break;
    case 9:
        cursor_pos.x = 90;
        cursor_pos.y = 192;
        return cursor_pos;
        break;
    case 10:
        cursor_pos.x = 56;
        cursor_pos.y = 124;
        return cursor_pos;
        break;
    }
}

void MainWindow::kill_participant(int pos) {
    switch (pos){
    case 1:
        ui->p1->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/killed.png)");
        break;
    case 2:
        ui->p2->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/killed.png)");
        break;
    case 3:
        ui->p3->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/killed.png)");
        break;
    case 4:
        ui->p4->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/killed.png)");
        break;
    case 5:
        ui->p5->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/killed.png)");
        break;
    case 6:
        ui->p6->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/killed.png)");
        break;
    case 7:
        ui->p7->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/killed.png)");
        break;
    case 8:
        ui->p8->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/killed.png)");
        break;
    case 9:
        ui->p9->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/killed.png)");
        break;
    case 10:
        ui->p10->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/killed.png)");
        break;
    }
}

void MainWindow::on_pushButton_2_clicked()
{
    if (participants[position - 1] != 0) {
        counter++;
    }

    struct Pos pos = find_cursor_position(position);

    ui->cursor->move(pos.x, pos.y);

    if(counter == K) {
        kill_participant(position);
        participants_alive--;
        participants[position - 1] = 0;
        counter = 0;
    }

    position++;
    if (position == 11) {
        position = 1;
    }

    if (participants_alive == 1) {
        restart_game();
        QString message = QString("Игрок %1 выиграл!").arg(position);
        QMessageBox::about(this, "Игра окончена", message);
    }
}

void MainWindow::getK () {
    bool ok;
    QString text = QInputDialog::getText(this, tr("Число К"),
                                         tr("Введите число K:"), QLineEdit::Normal,
                                         "5", &ok);

    K = text.toInt();
}

void MainWindow::on_pushButton_3_clicked()
{
    restart_game();
}

void MainWindow::restart_game() {
    participants = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
    counter = 0;
    position = 1;
    participants_alive = 10;
    ui->p1->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p2->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p3->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p4->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p5->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p6->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p7->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p8->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p9->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->p10->setStyleSheet("background-image: url(C:/Users/s3v3n/Documents/OCtask2/images/user.png)");
    ui->cursor->move(90, 58);
}
