#pragma once

#include <stdlib.h>
#include <time.h>

struct Participant {
	char name;
	int place;
};

struct Participant* create_participants(int n) {
	struct Participant* participants = (struct Participant*) malloc(sizeof(struct Participant) * n);

	char name = 'A';
	for (int i = 0; i < n; i++) {
		participants[i].name = name;
		participants[i].place = -1;
		name += 1;
	}

	return participants;
}

void place_participants(struct Participant* participants, int n, int max_place) {
	srand(time(NULL));

	int placed = 0;
	while (placed != n) {
		int place = rand() % max_place;
		
		int have_placed = 0;
		for (int i = 0; i < placed; i++) {
			if (participants[i].place == place) {
				have_placed = 1;
				break;
			}
		}

		if (!have_placed) {
			participants[placed].place = place;
			placed++;
		}
	}
}
