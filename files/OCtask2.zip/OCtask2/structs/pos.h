#pragma once

struct Pos {
	int x;
	int y;
};
