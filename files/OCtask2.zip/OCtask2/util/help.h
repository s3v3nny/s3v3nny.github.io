#pragma once

#include <stdio.h>

void display_usage(char* executable_name) {
	printf("Usage:\n");
	printf("./%s N K\n", executable_name);
	printf("N - amount of participants\n");
	printf("K - counter\n");
}
