#pragma once

#include <string.h>

char* get_executable_name(char* filepath) {
	char* result = NULL;
	char* new_token = strtok(filepath, "/");
	
	while (new_token != NULL) {
		result = new_token;
		new_token = strtok(NULL, "/");
	}

	return result;
}
